// ============================================================
// lib/clipper.js
// Downloads a source YouTube video and cuts a vertical TikTok-
// ready clip that is ALWAYS >= MIN_CLIP_SECONDS long (default 60).
//
// Requires `ffmpeg` to be present on PATH — added via railway.toml
// nixPkgs. Requires the `@distube/ytdl-core` npm package — added
// to package.json.
// ============================================================

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const ytdl = require('@distube/ytdl-core');

const MIN_CLIP_SECONDS = parseInt(process.env.MIN_CLIP_SECONDS || '60', 10);
const TARGET_CLIP_SECONDS = parseInt(process.env.TARGET_CLIP_SECONDS || '65', 10);

function tmpPath(ext) {
  return path.join(os.tmpdir(), `viralagent-${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`);
}

function downloadVideo(youtubeUrl) {
  return new Promise((resolve, reject) => {
    const dest = tmpPath('mp4');
    const stream = ytdl(youtubeUrl, { quality: 'highest', filter: 'audioandvideo' });
    const file = fs.createWriteStream(dest);
    let failed = false;

    stream.on('error', (err) => {
      failed = true;
      reject(new Error(`YouTube download failed: ${err.message}`));
    });
    file.on('error', (err) => {
      failed = true;
      reject(new Error(`Writing downloaded video failed: ${err.message}`));
    });
    file.on('finish', () => {
      if (!failed) resolve(dest);
    });

    stream.pipe(file);
  });
}

function runFfmpeg(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stderr = '';
    proc.stderr.on('data', (d) => { stderr += d.toString(); });
    proc.on('error', (err) => reject(new Error(`ffmpeg failed to start (is it installed? check railway.toml nixPkgs): ${err.message}`)));
    proc.on('close', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`ffmpeg exited with code ${code}: ${stderr.slice(-800)}`));
    });
  });
}

function pickClipWindow(sourceDurationSec) {
  const introBuffer = 3;
  const outroBuffer = 5;
  const usableStart = introBuffer;
  const usableEnd = Math.max(usableStart, sourceDurationSec - outroBuffer);
  const available = usableEnd - usableStart - TARGET_CLIP_SECONDS;

  if (available <= 0) {
    // Source barely long enough — just take from the start, full available length.
    const len = Math.max(MIN_CLIP_SECONDS, Math.min(TARGET_CLIP_SECONDS, sourceDurationSec));
    return { startSec: 0, lenSec: Math.min(len, sourceDurationSec) };
  }

  const startSec = usableStart + Math.floor(Math.random() * available);
  return { startSec, lenSec: TARGET_CLIP_SECONDS };
}

async function clipToVertical(srcPath, startSec, lenSec) {
  const dest = tmpPath('mp4');
  const args = [
    '-y',
    '-ss', String(startSec),
    '-i', srcPath,
    '-t', String(lenSec),
    '-vf', 'scale=w=1080:h=1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30',
    '-c:v', 'libx264',
    '-preset', 'veryfast',
    '-crf', '21',
    '-c:a', 'aac',
    '-b:a', '128k',
    '-movflags', '+faststart',
    dest,
  ];
  await runFfmpeg(args);
  return dest;
}

function probeDurationSec(filePath) {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffprobe', [
      '-v', 'error', '-show_entries', 'format=duration',
      '-of', 'default=noprint_wrappers=1:nokey=1', filePath,
    ]);
    let out = '';
    proc.stdout.on('data', (d) => { out += d.toString(); });
    proc.on('close', () => resolve(parseFloat(out.trim()) || 0));
    proc.on('error', reject);
  });
}

// ── Main entry point ──
// video: { url, durationSec, title }
// Returns { filePath, durationSec } — caller is responsible for
// deleting filePath after it's done (e.g. after posting).
async function createClipFromYouTube(video) {
  const srcPath = await downloadVideo(video.url);
  try {
    const { startSec, lenSec } = pickClipWindow(video.durationSec);
    const clipPath = await clipToVertical(srcPath, startSec, lenSec);
    const actualDuration = await probeDurationSec(clipPath);

    if (actualDuration < MIN_CLIP_SECONDS - 2) {
      // Safety net: if the cut came out short (e.g. source metadata was
      // wrong), don't silently post an under-length clip.
      fs.unlinkSync(clipPath);
      throw new Error(`Clip came out at ${actualDuration.toFixed(1)}s, below the ${MIN_CLIP_SECONDS}s minimum — source video too short for a clean cut.`);
    }

    return { filePath: clipPath, durationSec: actualDuration };
  } finally {
    fs.unlink(srcPath, () => {}); // best-effort cleanup of the raw download
  }
}

module.exports = { createClipFromYouTube, pickClipWindow, MIN_CLIP_SECONDS };
