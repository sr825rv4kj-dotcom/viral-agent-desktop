// ============================================================
// VIRAL AGENT SERVER — REBUILT WITH A REAL PIPELINE
// Replaces the old stub server.js. Every TODO from the old file
// is now wired to a real module: lib/store, lib/tiktok,
// lib/youtube, lib/clipper, lib/scheduler.
// ============================================================

const http = require('http');
const url = require('url');

const store = require('./lib/store');
const tiktok = require('./lib/tiktok');
const youtube = require('./lib/youtube');
const scheduler = require('./lib/scheduler');

const PORT = process.env.PORT || 3000;

store.load();
scheduler.resumeOnBoot(); // if the agent was running before a restart, bring it back automatically

// ── HTML Dashboard ──────────────────────────────────────────
function getDashboardHTML() {
  const s = store.get();
  const running = s.agent.running;
  const postsPerDay = s.config.postsPerDay;
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Viral Agent</title>
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg: #0a0a0f;
  --surface: #111118;
  --border: #1e1e2e;
  --accent: #7c3aed;
  --accent2: #06b6d4;
  --green: #10b981;
  --red: #ef4444;
  --yellow: #f59e0b;
  --text: #e2e8f0;
  --muted: #64748b;
  --radius: 12px;
}

body {
  background: var(--bg);
  color: var(--text);
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  min-height: 100vh;
  padding-bottom: 40px;
}

.header { background: linear-gradient(135deg, #1a0533 0%, #0a0a1a 60%); border-bottom: 1px solid var(--border); padding: 20px 24px 16px; }
.header-top { display: flex; align-items: center; justify-content: space-between; }
.logo { font-size: 22px; font-weight: 800; background: linear-gradient(90deg, #a855f7, #06b6d4); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
.status-pill { display: flex; align-items: center; gap: 6px; padding: 4px 12px; border-radius: 999px; font-size: 12px; font-weight: 600; border: 1px solid currentColor; }
.status-pill.online { color: var(--green); background: rgba(16,185,129,.1); }
.status-pill.offline { color: var(--muted); background: rgba(100,116,139,.1); }
.status-dot { width: 7px; height: 7px; border-radius: 50%; background: currentColor; }
.status-dot.pulse { animation: pulse 1.5s infinite; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.3} }

.stats-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; padding: 16px 24px 0; }
.stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 14px; text-align: center; }
.stat-number { font-size: 28px; font-weight: 800; color: var(--accent2); line-height: 1; }
.stat-label { font-size: 11px; color: var(--muted); margin-top: 4px; }

.tabs-nav { display: flex; gap: 4px; padding: 12px 24px 0; border-bottom: 1px solid var(--border); overflow-x: auto; }
.tab-btn { background: transparent; border: none; color: var(--muted); padding: 10px 16px; border-radius: 8px 8px 0 0; font-size: 13px; font-weight: 600; cursor: pointer; white-space: nowrap; border-bottom: 2px solid transparent; transition: all .2s; -webkit-tap-highlight-color: transparent; }
.tab-btn:hover { color: var(--text); background: rgba(255,255,255,.04); }
.tab-btn.active { color: var(--accent2); border-bottom-color: var(--accent2); background: rgba(6,182,212,.06); }

.tab-panel { display: none; padding: 20px 24px; }
.tab-panel.active { display: block; }

.card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; margin-bottom: 16px; }
.card-title { font-size: 14px; font-weight: 700; color: var(--text); margin-bottom: 14px; display: flex; align-items: center; gap: 8px; }

.banner { border-radius: var(--radius); padding: 12px 16px; font-size: 12px; margin-bottom: 16px; border: 1px solid currentColor; }
.banner.warn { color: var(--yellow); background: rgba(245,158,11,.08); }
.banner.error { color: var(--red); background: rgba(239,68,68,.08); }
.banner.ok { color: var(--green); background: rgba(16,185,129,.08); }

.btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 12px 24px; border: none; border-radius: 10px; font-size: 14px; font-weight: 700; cursor: pointer; transition: all .18s; -webkit-tap-highlight-color: transparent; min-height: 44px; }
.btn:active { transform: scale(.97); }
.btn-primary { background: linear-gradient(135deg, var(--accent), #9333ea); color: #fff; width: 100%; }
.btn-primary:hover { opacity: .9; }
.btn-danger { background: linear-gradient(135deg, var(--red), #dc2626); color: #fff; width: 100%; }
.btn-secondary { background: var(--border); color: var(--text); }
.btn:disabled { opacity: .45; cursor: not-allowed; }

.log-feed { background: #06060c; border: 1px solid var(--border); border-radius: 8px; padding: 12px; font-family: 'SF Mono', Consolas, monospace; font-size: 11px; color: #94a3b8; max-height: 220px; overflow-y: auto; line-height: 1.6; }
.log-entry { padding: 1px 0; }

.field { margin-bottom: 14px; }
.field label { display: block; font-size: 12px; font-weight: 600; color: var(--muted); margin-bottom: 6px; }
.field input, .field select { width: 100%; background: #0d0d18; border: 1px solid var(--border); border-radius: 8px; color: var(--text); padding: 10px 14px; font-size: 14px; }
.field input:focus, .field select:focus { outline: none; border-color: var(--accent); }

#toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%) translateY(80px); background: var(--surface); border: 1px solid var(--border); color: var(--text); padding: 10px 20px; border-radius: 999px; font-size: 13px; font-weight: 600; transition: transform .3s ease; z-index: 999; pointer-events: none; }
#toast.show { transform: translateX(-50%) translateY(0); }
#toast.success { border-color: var(--green); color: var(--green); }
#toast.error { border-color: var(--red); color: var(--red); }

.badge { display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 11px; font-weight: 700; }
.badge-green { background: rgba(16,185,129,.15); color: var(--green); }
.badge-yellow { background: rgba(245,158,11,.15); color: var(--yellow); }
.badge-red { background: rgba(239,68,68,.15); color: var(--red); }
.section-title { font-size: 11px; font-weight: 700; color: var(--muted); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 10px; }
.row { display: flex; gap: 10px; }
.row .btn { flex: 1; }
.clip-row { padding: 10px 0; border-bottom: 1px solid var(--border); font-size: 13px; }
.clip-row .err { color: var(--red); font-size: 11px; margin-top: 4px; }
.kv { display: flex; justify-content: space-between; padding: 4px 0; font-size: 12px; }
</style>
</head>
<body>

<div class="header">
  <div class="header-top">
    <div class="logo">⚡ Viral Agent</div>
    <div id="statusPill" class="status-pill ${running ? 'online' : 'offline'}">
      <div class="status-dot ${running ? 'pulse' : ''}"></div>
      <span id="statusText">${running ? 'LIVE' : 'OFFLINE'}</span>
    </div>
  </div>
</div>

<div class="stats-row">
  <div class="stat-card"><div class="stat-number" id="statToday">${s.stats.postsToday}</div><div class="stat-label">Posts Today</div></div>
  <div class="stat-card"><div class="stat-number" id="statTotal">${s.stats.totalPosts}</div><div class="stat-label">Total Posts</div></div>
  <div class="stat-card"><div class="stat-number" id="statTarget">${postsPerDay}</div><div class="stat-label">Daily Target</div></div>
</div>

<div class="tabs-nav">
  <button class="tab-btn active" data-tab="agent">🤖 Agent</button>
  <button class="tab-btn" data-tab="clips">✂️ Clips</button>
  <button class="tab-btn" data-tab="learn">📈 Learn</button>
  <button class="tab-btn" data-tab="setup">⚙️ Setup</button>
</div>

<div id="tab-agent" class="tab-panel active">
  <div id="agentBanner"></div>

  <div class="card">
    <div class="card-title">🚀 Agent Control</div>
    <button id="btnStart" class="btn btn-primary" style="${running ? 'display:none' : ''}">▶ Start Automated Posting</button>
    <button id="btnStop" class="btn btn-danger" style="${running ? '' : 'display:none'}">⏹ Stop Agent</button>
    <p id="agentNote" style="margin-top:10px;font-size:12px;color:var(--muted);text-align:center;">
      ${running ? 'Agent is running. It will keep running 24/7 and auto-resumes after restarts.' : 'Tap Start to begin the 24/7 posting loop.'}
    </p>
  </div>

  <div class="card">
    <div class="card-title">📋 Live Logs</div>
    <div class="log-feed" id="logFeed">
      ${s.logs.length ? s.logs.slice(0, 50).map(l => `<div class="log-entry">${escHtmlServer(l)}</div>`).join('') : '<div class="log-entry" style="color:var(--muted)">No logs yet — start the agent to begin.</div>'}
    </div>
  </div>

  <div class="card">
    <div class="card-title">⚡ Quick Actions</div>
    <div class="row" style="margin-bottom:10px;">
      <button class="btn btn-secondary" id="btnDiscover">🔍 Discover Videos</button>
      <button class="btn btn-secondary" id="btnPost">📤 Post Now</button>
    </div>
    <button class="btn btn-secondary" id="btnRefresh" style="width:100%;">🔄 Refresh Status</button>
  </div>
</div>

<div id="tab-clips" class="tab-panel">
  <div class="card">
    <div class="card-title">✂️ Recent Clips</div>
    <div id="clipsContent" style="color:var(--muted);font-size:13px;text-align:center;padding:20px 0;">Loading clips…</div>
  </div>
</div>

<div id="tab-learn" class="tab-panel">
  <div class="card">
    <div class="card-title">📈 Performance</div>
    <div id="learnContent" style="font-size:13px;">Loading…</div>
  </div>
  <div class="card">
    <div class="card-title">🧠 Current Settings</div>
    <div class="field"><label>Min Viral Score Threshold</label><input type="number" value="${store.get().config.minViralScore}" readonly /></div>
  </div>
</div>

<div id="tab-setup" class="tab-panel">
  <div class="card">
    <div class="card-title">🔗 TikTok Connection</div>
    <div id="tiktokStatus" style="font-size:12px;color:var(--muted);margin-bottom:12px;">Checking…</div>
    <button class="btn btn-primary" id="btnTikTok">Connect / Reconnect TikTok Account</button>
  </div>

  <div class="card">
    <div class="card-title">⚙️ Posting Config</div>
    <div class="field"><label>Posts Per Day</label><input type="number" id="cfgPostsPerDay" value="${postsPerDay}" min="1" max="50" /></div>
    <div class="field"><label>Min Viral Score (0–100)</label><input type="number" id="cfgViralScore" value="${store.get().config.minViralScore}" min="0" max="100" /></div>
    <button class="btn btn-primary" id="btnSaveConfig">💾 Save Config</button>
  </div>

  <div class="card">
    <div class="card-title">🔑 Environment Status</div>
    <div id="envStatus" style="font-size:12px;color:var(--muted);">Checking…</div>
  </div>

  <div class="card">
    <div class="card-title">🩺 Recent Errors</div>
    <div id="errorsContent" style="font-size:12px;color:var(--muted);">Checking…</div>
  </div>
</div>

<div id="toast"></div>

<script>
(function () {
'use strict';
function $(sel) { return document.querySelector(sel); }
function $$(sel) { return Array.from(document.querySelectorAll(sel)); }

function showToast(msg, type) {
  var t = $('#toast'); if (!t) return;
  t.textContent = msg; t.className = 'show ' + (type || '');
  clearTimeout(t._timer);
  t._timer = setTimeout(function () { t.className = ''; }, 3000);
}

function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

async function api(endpoint, method, body) {
  try {
    var opts = { method: method || 'GET', headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    var res = await fetch(endpoint, opts);
    return await res.json();
  } catch (e) {
    console.error('API error', endpoint, e);
    showToast('Network error — check Railway logs', 'error');
    return null;
  }
}

function initTabs() {
  var buttons = $$('.tab-btn'), panels = $$('.tab-panel');
  buttons.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var target = btn.getAttribute('data-tab');
      buttons.forEach(function (b) { b.classList.remove('active'); });
      panels.forEach(function (p) { p.classList.remove('active'); });
      btn.classList.add('active');
      var panel = document.getElementById('tab-' + target);
      if (panel) {
        panel.classList.add('active');
        if (target === 'clips') loadClips();
        if (target === 'setup') { loadEnvStatus(); loadTikTokStatus(); loadErrors(); }
        if (target === 'learn') loadLearn();
      }
    });
  });
}

async function refreshStatus() {
  var data = await api('/api/status');
  if (!data) return;

  var pill = $('#statusPill'), dot = pill && pill.querySelector('.status-dot');
  var txt = $('#statusText'), note = $('#agentNote');
  var start = $('#btnStart'), stop = $('#btnStop'), logFeed = $('#logFeed');
  var banner = $('#agentBanner');

  if (txt) txt.textContent = data.running ? 'LIVE' : 'OFFLINE';
  if (pill) pill.className = 'status-pill ' + (data.running ? 'online' : 'offline');
  if (dot) dot.className = 'status-dot ' + (data.running ? 'pulse' : '');
  if (start) start.style.display = data.running ? 'none' : '';
  if (stop) stop.style.display = data.running ? '' : 'none';
  if (note) note.textContent = data.running ? 'Agent is running. It will keep running 24/7 and auto-resumes after restarts.' : 'Tap Start to begin the 24/7 posting loop.';

  var s = $('#statToday'); if (s) s.textContent = data.postsToday || 0;
  var t = $('#statTotal'); if (t) t.textContent = data.totalPosts || 0;

  if (logFeed && data.logs) {
    logFeed.innerHTML = data.logs.length
      ? data.logs.map(function(l){ return '<div class="log-entry">' + escHtml(l) + '</div>'; }).join('')
      : '<div class="log-entry" style="color:var(--muted)">No logs yet.</div>';
  }

  if (banner) {
    if (data.running && !data.tiktokConnected) {
      banner.innerHTML = '<div class="banner warn">⚠️ Agent is running, but TikTok isn\\'t connected yet — it will keep retrying and logging, but nothing will post until you connect TikTok in the Setup tab.</div>';
    } else {
      banner.innerHTML = '';
    }
  }
}

async function loadClips() {
  var el = $('#clipsContent'); if (!el) return;
  el.textContent = 'Loading…';
  var data = await api('/api/clips');
  if (!data || !data.clips || !data.clips.length) {
    el.innerHTML = '<div style="padding:20px 0;text-align:center;font-size:13px;color:var(--muted)">No clips yet. Start the agent or tap "Discover Videos" / "Post Now" on the Agent tab.</div>';
    return;
  }
  el.innerHTML = data.clips.map(function(c) {
    var badgeClass = c.status === 'posted' ? 'green' : (c.status === 'failed' ? 'red' : 'yellow');
    var errLine = c.error ? '<div class="err">' + escHtml(c.error) + '</div>' : '';
    var durLine = c.durationSec ? ' · ' + Math.round(c.durationSec) + 's' : '';
    return '<div class="clip-row"><strong>' + escHtml(c.title || 'Untitled') + '</strong>'
      + '<span style="margin-left:8px;" class="badge badge-' + badgeClass + '">' + c.status + '</span>'
      + '<span style="color:var(--muted)">' + durLine + '</span>' + errLine + '</div>';
  }).join('');
}

async function loadLearn() {
  var el = $('#learnContent'); if (!el) return;
  var data = await api('/api/clips');
  if (!data) return;
  var posted = (data.clips || []).filter(function(c){ return c.status === 'posted'; });
  if (!posted.length) {
    el.innerHTML = '<div style="text-align:center;color:var(--muted);padding:16px 0;">📊 Performance data will appear here after your first posts go live.</div>';
    return;
  }
  el.innerHTML = '<div class="kv"><span>Total posted</span><span>' + posted.length + '</span></div>'
    + '<div class="kv"><span>Most recent</span><span>' + escHtml(posted[0].title) + '</span></div>'
    + '<p style="margin-top:10px;font-size:11px;color:var(--muted);">Per-video view/like counts require TikTok\\'s Display/Research API and aren\\'t wired up yet — this shows what the agent itself has posted so far.</p>';
}

async function loadEnvStatus() {
  var el = $('#envStatus'); if (!el) return;
  var data = await api('/api/env-check');
  if (!data) return;
  el.innerHTML = Object.entries(data).map(function(kv) {
    var ok = kv[1];
    return '<div class="kv"><span>' + escHtml(kv[0]) + '</span><span style="color:' + (ok ? 'var(--green)' : 'var(--red)') + '">' + (ok ? '✓ Set' : '✗ Missing') + '</span></div>';
  }).join('');
}

async function loadTikTokStatus() {
  var el = $('#tiktokStatus'); if (!el) return;
  el.textContent = 'Checking…';
  var data = await api('/api/tiktok/status');
  if (!data) { el.textContent = 'Could not check status.'; return; }
  if (!data.connected) {
    el.innerHTML = '<div class="banner warn">Not connected yet. Tap the button below.</div>';
    return;
  }
  var lines = '<div class="banner ok">✓ Connected (open_id: ' + escHtml((data.openId || '').slice(0,8)) + '…)</div>';
  if (data.privacyLevelOptions) {
    var isPublic = data.privacyLevelOptions.indexOf('PUBLIC_TO_EVERYONE') !== -1;
    lines += '<div class="banner ' + (isPublic ? 'ok' : 'warn') + '">'
      + (isPublic
        ? '✓ Public posting is allowed for this account.'
        : '⚠️ TikTok is currently only allowing private (' + escHtml(data.privacyLevelOptions.join(', ')) + ') posts for this app. This is a TikTok-side restriction until your Developer app passes their audit — it is not a bug in this code. Posts will still go through, just privately, until that\\'s approved.')
      + '</div>';
  }
  if (data.error) {
    lines += '<div class="banner error">' + escHtml(data.error) + '</div>';
  }
  el.innerHTML = lines;
}

async function loadErrors() {
  var el = $('#errorsContent'); if (!el) return;
  var data = await api('/api/errors');
  if (!data || !data.errors || !data.errors.length) {
    el.innerHTML = '<div style="color:var(--muted)">No errors logged. 🎉</div>';
    return;
  }
  el.innerHTML = data.errors.slice(0, 15).map(function(e) {
    return '<div class="kv"><span>' + escHtml(e.at) + '</span><span style="color:var(--red);text-align:right;max-width:65%;">' + escHtml(e.message) + '</span></div>';
  }).join('');
}

function initAgentButtons() {
  var btnStart = $('#btnStart'), btnStop = $('#btnStop');
  var btnDiscover = $('#btnDiscover'), btnPost = $('#btnPost'), btnRefresh = $('#btnRefresh');

  if (btnStart) btnStart.addEventListener('click', async function () {
    btnStart.disabled = true; btnStart.textContent = '⏳ Starting…';
    var data = await api('/api/agent/start', 'POST');
    if (data && data.success) { showToast('Agent started!', 'success'); await refreshStatus(); }
    else { showToast((data && data.error) || 'Failed to start agent', 'error'); }
    btnStart.disabled = false; btnStart.textContent = '▶ Start Automated Posting';
  });

  if (btnStop) btnStop.addEventListener('click', async function () {
    btnStop.disabled = true;
    var data = await api('/api/agent/stop', 'POST');
    if (data && data.success) { showToast('Agent stopped', 'success'); await refreshStatus(); }
    else { showToast('Failed to stop agent', 'error'); }
    btnStop.disabled = false;
  });

  if (btnDiscover) btnDiscover.addEventListener('click', async function () {
    btnDiscover.disabled = true; btnDiscover.textContent = '⏳ Discovering…';
    var data = await api('/api/discover', 'POST');
    if (data && data.success) showToast('Found ' + (data.count || 0) + ' eligible videos', 'success');
    else showToast((data && data.error) || 'Discovery failed', 'error');
    btnDiscover.disabled = false; btnDiscover.textContent = '🔍 Discover Videos';
    await refreshStatus();
  });

  if (btnPost) btnPost.addEventListener('click', async function () {
    btnPost.disabled = true; btnPost.textContent = '⏳ Posting (this can take ~30–90s)…';
    var data = await api('/api/post/now', 'POST');
    if (data && data.success) showToast('Posted to TikTok!', 'success');
    else showToast((data && data.error) || 'Post failed — see Setup > Recent Errors', 'error');
    btnPost.disabled = false; btnPost.textContent = '📤 Post Now';
    await refreshStatus();
  });

  if (btnRefresh) btnRefresh.addEventListener('click', async function () {
    btnRefresh.textContent = '⏳ Refreshing…';
    await refreshStatus();
    btnRefresh.textContent = '🔄 Refresh Status';
    showToast('Status updated', 'success');
  });
}

function initSetupButtons() {
  var btnTikTok = $('#btnTikTok');
  if (btnTikTok) btnTikTok.addEventListener('click', function () { window.location.href = '/auth/tiktok'; });

  var btnSave = $('#btnSaveConfig');
  if (btnSave) btnSave.addEventListener('click', async function () {
    var ppd = $('#cfgPostsPerDay'), vs = $('#cfgViralScore');
    btnSave.disabled = true; btnSave.textContent = '💾 Saving…';
    var data = await api('/api/config', 'POST', {
      postsPerDay: ppd ? parseInt(ppd.value, 10) : 15,
      minViralScore: vs ? parseInt(vs.value, 10) : 70,
    });
    if (data && data.success) showToast('Config saved!', 'success');
    else showToast('Save failed', 'error');
    btnSave.disabled = false; btnSave.textContent = '💾 Save Config';
    await refreshStatus();
  });
}

document.addEventListener('DOMContentLoaded', function () {
  initTabs();
  initAgentButtons();
  initSetupButtons();
  refreshStatus();
  loadEnvStatus();
  loadTikTokStatus();
  // Check for ?tiktok=connected / ?tiktok=error in the URL after OAuth redirect
  var params = new URLSearchParams(window.location.search);
  if (params.get('tiktok') === 'connected') showToast('TikTok connected!', 'success');
  if (params.get('tiktok') === 'error') showToast('TikTok connection failed: ' + (params.get('msg') || 'unknown error'), 'error');
  setInterval(refreshStatus, 15000);
});
})();
</script>
</body>
</html>`;
}

function escHtmlServer(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ── API handlers ─────────────────────────────────────────────

function handleStatus(res) {
  const s = store.get();
  sendJSON(res, 200, {
    running: s.agent.running,
    postsToday: s.stats.postsToday,
    totalPosts: s.stats.totalPosts,
    lastPost: s.stats.lastPost,
    startedAt: s.agent.startedAt,
    lastTickAt: s.agent.lastTickAt,
    logs: s.logs.slice(0, 50),
    postsPerDay: s.config.postsPerDay,
    tiktokConnected: tiktok.isConnected(),
  });
}

function handleAgentStart(res) {
  scheduler.start();
  sendJSON(res, 200, { success: true });
}

function handleAgentStop(res) {
  scheduler.stop();
  sendJSON(res, 200, { success: true });
}

async function handleDiscover(res) {
  try {
    const excludeIds = store.get().clips.map((c) => c.sourceVideoId).filter(Boolean);
    const candidates = await youtube.discoverCandidateVideos({ limit: 10, excludeIds });
    sendJSON(res, 200, { success: true, count: candidates.length, videos: candidates });
  } catch (err) {
    sendJSON(res, 200, { success: false, error: err.message });
  }
}

async function handlePostNow(res) {
  try {
    await scheduler.tick();
    const s = store.get();
    const latest = s.clips[0];
    if (latest && latest.status === 'posted') {
      sendJSON(res, 200, { success: true, clip: latest });
    } else {
      sendJSON(res, 200, { success: false, error: (latest && latest.error) || 'No eligible video / nothing posted this run — check logs.' });
    }
  } catch (err) {
    sendJSON(res, 200, { success: false, error: err.message });
  }
}

function handleClips(res) {
  sendJSON(res, 200, { clips: store.get().clips.slice(0, 50) });
}

function handleErrors(res) {
  sendJSON(res, 200, { errors: store.get().errors });
}

function handleConfig(res, body) {
  scheduler.updateConfig(body || {});
  scheduler.log(`Config updated: ${JSON.stringify(body)}`);
  sendJSON(res, 200, { success: true, config: store.get().config });
}

function handleEnvCheck(res) {
  const vars = [
    'YOUTUBE_API_KEY',
    'YOUTUBE_CHANNEL_ID',
    'TIKTOK_CLIENT_KEY',
    'TIKTOK_CLIENT_SECRET',
    'TIKTOK_REDIRECT_URI',
    'DATA_DIR',
    'POSTS_PER_DAY',
  ];
  const result = {};
  vars.forEach((v) => { result[v] = !!process.env[v]; });
  result['TikTok actually connected (token saved)'] = tiktok.isConnected();
  sendJSON(res, 200, result);
}

async function handleTikTokStatusApi(res) {
  if (!tiktok.isConnected()) {
    return sendJSON(res, 200, { connected: false });
  }
  try {
    const info = await tiktok.queryCreatorInfo();
    sendJSON(res, 200, {
      connected: true,
      openId: store.get().tiktok.open_id,
      privacyLevelOptions: info.privacy_level_options,
    });
  } catch (err) {
    sendJSON(res, 200, { connected: true, error: err.message });
  }
}

function handleTikTokAuth(res) {
  if (!process.env.TIKTOK_CLIENT_KEY) {
    res.writeHead(302, { Location: '/?tiktok=error&msg=' + encodeURIComponent('TIKTOK_CLIENT_KEY not set in Railway') });
    return res.end();
  }
  res.writeHead(302, { Location: tiktok.getAuthorizeUrl() });
  res.end();
}

async function handleTikTokCallback(res, parsedUrl) {
  const { code, error, error_description } = parsedUrl.query;
  if (error) {
    scheduler.logError(new Error(`TikTok auth denied: ${error_description || error}`));
    res.writeHead(302, { Location: '/?tiktok=error&msg=' + encodeURIComponent(error_description || error) });
    return res.end();
  }
  if (!code) {
    res.writeHead(302, { Location: '/?tiktok=error&msg=' + encodeURIComponent('No authorization code returned by TikTok') });
    return res.end();
  }
  try {
    await tiktok.exchangeCodeForToken(code);
    scheduler.log('✅ TikTok connected and token saved persistently.');
    res.writeHead(302, { Location: '/?tiktok=connected' });
  } catch (err) {
    scheduler.logError(err);
    res.writeHead(302, { Location: '/?tiktok=error&msg=' + encodeURIComponent(err.message) });
  }
  res.end();
}

// ── HTTP plumbing ─────────────────────────────────────────────

function sendJSON(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', (chunk) => { data += chunk; });
    req.on('end', () => {
      try { resolve(JSON.parse(data)); } catch { resolve({}); }
    });
  });
}

const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method.toUpperCase();

  if (method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' });
    return res.end();
  }

  try {
    if (pathname === '/' && method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(getDashboardHTML());
    }

    if (pathname === '/api/status' && method === 'GET') return handleStatus(res);
    if (pathname === '/api/agent/start' && method === 'POST') return handleAgentStart(res);
    if (pathname === '/api/agent/stop' && method === 'POST') return handleAgentStop(res);
    if (pathname === '/api/discover' && method === 'POST') return await handleDiscover(res);
    if (pathname === '/api/post/now' && method === 'POST') return await handlePostNow(res);
    if (pathname === '/api/clips' && method === 'GET') return handleClips(res);
    if (pathname === '/api/errors' && method === 'GET') return handleErrors(res);
    if (pathname === '/api/env-check' && method === 'GET') return handleEnvCheck(res);
    if (pathname === '/api/tiktok/status' && method === 'GET') return await handleTikTokStatusApi(res);
    if (pathname === '/auth/tiktok' && method === 'GET') return handleTikTokAuth(res);
    if (pathname === '/auth/tiktok/callback' && method === 'GET') return await handleTikTokCallback(res, parsedUrl);

    if (pathname === '/api/config' && method === 'POST') {
      const body = await readBody(req);
      return handleConfig(res, body);
    }

    if (pathname === '/health') {
      res.writeHead(200);
      return res.end('OK');
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not found', path: pathname }));
  } catch (err) {
    console.error('Unhandled request error:', err);
    scheduler.logError(err);
    sendJSON(res, 500, { error: 'Internal server error', message: err.message });
  }
});

server.listen(PORT, () => {
  scheduler.log(`✅ Viral Agent server running on port ${PORT} (Node ${process.version})`);
  scheduler.log(`Data persisted at ${store.DB_FILE}`);
});

server.on('error', (err) => {
  console.error('Server error:', err);
  process.exit(1);
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught exception (server stays up):', err);
  scheduler.logError(err);
});
process.on('unhandledRejection', (err) => {
  console.error('Unhandled rejection (server stays up):', err);
  scheduler.logError(err instanceof Error ? err : new Error(String(err)));
});
