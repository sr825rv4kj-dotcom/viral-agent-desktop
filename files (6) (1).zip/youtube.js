// ============================================================
// lib/youtube.js
// Finds source videos to turn into TikTok clips.
//
// SAFETY DEFAULT: pulls from YOUR OWN channel (YOUTUBE_CHANNEL_ID).
// Re-uploading other people's YouTube videos to TikTok without
// rights is a copyright/ToS risk to your TikTok account (claims,
// strikes, bans) — TikTok's own moderation can also pull a post
// after the fact for this. If you have an explicit license or
// you only want Creative-Commons-licensed material, set
// YOUTUBE_MODE=search and YOUTUBE_SEARCH_QUERY, which restricts
// results to videoLicense=creativeCommon automatically.
// ============================================================

const YT_BASE = 'https://www.googleapis.com/youtube/v3';

function apiKey() {
  const key = process.env.YOUTUBE_API_KEY;
  if (!key) throw new Error('YOUTUBE_API_KEY not set in Railway env vars');
  return key;
}

function isoDurationToSeconds(iso) {
  // e.g. PT1H2M10S
  const m = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(iso || '');
  if (!m) return 0;
  const h = parseInt(m[1] || '0', 10);
  const mi = parseInt(m[2] || '0', 10);
  const s = parseInt(m[3] || '0', 10);
  return h * 3600 + mi * 60 + s;
}

async function ytGet(path, params) {
  const usp = new URLSearchParams({ key: apiKey(), ...params });
  const res = await fetch(`${YT_BASE}${path}?${usp.toString()}`);
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json.error) {
    throw new Error(`YouTube API error (${path}): ${json.error?.message || res.status}`);
  }
  return json;
}

async function getUploadsPlaylistId(channelId) {
  const json = await ytGet('/channels', { part: 'contentDetails', id: channelId });
  const item = json.items && json.items[0];
  if (!item) throw new Error(`No YouTube channel found for ID ${channelId}`);
  return item.contentDetails.relatedPlaylists.uploads;
}

async function videosFromPlaylist(playlistId, maxResults) {
  const json = await ytGet('/playlistItems', {
    part: 'contentDetails,snippet',
    playlistId,
    maxResults: String(Math.min(maxResults || 15, 50)),
  });
  return (json.items || []).map((it) => ({
    videoId: it.contentDetails.videoId,
    title: it.snippet.title,
    publishedAt: it.contentDetails.videoPublishedAt,
  }));
}

async function videosFromSearch(query, maxResults) {
  const json = await ytGet('/search', {
    part: 'snippet',
    q: query,
    type: 'video',
    videoLicense: 'creativeCommon', // only CC-licensed videos are legally safe to reuse
    maxResults: String(Math.min(maxResults || 15, 50)),
  });
  return (json.items || []).map((it) => ({
    videoId: it.id.videoId,
    title: it.snippet.title,
    publishedAt: it.snippet.publishedAt,
  }));
}

async function withDurations(videos) {
  if (!videos.length) return [];
  const ids = videos.map((v) => v.videoId).join(',');
  const json = await ytGet('/videos', { part: 'contentDetails,statistics', id: ids });
  const durationById = {};
  const statsById = {};
  for (const it of json.items || []) {
    durationById[it.id] = isoDurationToSeconds(it.contentDetails.duration);
    statsById[it.id] = it.statistics;
  }
  return videos.map((v) => ({
    ...v,
    durationSec: durationById[v.videoId] || 0,
    viewCount: parseInt((statsById[v.videoId] || {}).viewCount || '0', 10),
    url: `https://www.youtube.com/watch?v=${v.videoId}`,
  }));
}

// ── Main entry point ──
// excludeIds: video IDs already turned into clips, so we don't repeat ourselves.
async function discoverCandidateVideos({ limit = 10, excludeIds = [] } = {}) {
  const mode = process.env.YOUTUBE_MODE || 'channel';
  let raw;

  if (mode === 'search') {
    const query = process.env.YOUTUBE_SEARCH_QUERY;
    if (!query) throw new Error('YOUTUBE_MODE=search requires YOUTUBE_SEARCH_QUERY to be set');
    raw = await videosFromSearch(query, limit * 2);
  } else {
    const channelId = process.env.YOUTUBE_CHANNEL_ID;
    if (!channelId) throw new Error('YOUTUBE_CHANNEL_ID not set — required for YOUTUBE_MODE=channel (the default, and the legally safe option)');
    const playlistId = await getUploadsPlaylistId(channelId);
    raw = await videosFromPlaylist(playlistId, limit * 2);
  }

  const withDur = await withDurations(raw);

  const MIN_SOURCE_LEN = 75; // need enough source footage to cut a clean 60s+ clip with a tiny buffer
  const excludeSet = new Set(excludeIds);

  return withDur
    .filter((v) => v.durationSec >= MIN_SOURCE_LEN)
    .filter((v) => !excludeSet.has(v.videoId))
    .slice(0, limit);
}

module.exports = { discoverCandidateVideos, isoDurationToSeconds };
