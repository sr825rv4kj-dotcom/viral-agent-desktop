# Viral Agent — Setup Guide (v2)

This replaces the old stub server with a real pipeline. Follow this once, in order.

## 0. What changed, in one sentence
The old `server.js` had a working dashboard UI but every button and the 24/7 loop were placeholders (`TODO`s) that faked success — nothing was ever downloaded, clipped, or posted, and your TikTok login code was received but never exchanged for a token or saved. This version actually does all of that, and persists everything so it survives restarts.

---

## 1. TikTok Developer App

1. Go to https://developers.tiktok.com/ → **Manage apps** → create an app (or use your existing one).
2. Add the **Login Kit** and **Content Posting API** products to the app.
3. Under app settings, copy your **Client Key** and **Client Secret**.
4. Add a **Redirect URI**: `https://<your-railway-domain>/auth/tiktok/callback`
   (find your Railway domain in Railway → your service → Settings → Networking → Public Domain)
5. Scopes needed: `user.info.basic`, `video.publish`, `video.upload`.

**Important reality check, not a bug you can fix in code:** until TikTok manually audits your app, every post it makes will be forced to **private (SELF_ONLY)** visibility, and only up to 5 TikTok accounts can connect to it per day. This is TikTok's platform rule for all unaudited apps. The dashboard's Setup tab now tells you honestly which mode you're in (look for the green "public posting allowed" banner vs the yellow "private only" banner). When you're ready, apply for the audit from your TikTok developer dashboard — it typically takes a couple of weeks.

## 2. YouTube Data API

1. Go to https://console.cloud.google.com/ → create/select a project → **APIs & Services → Library** → enable **YouTube Data API v3**.
2. **Credentials → Create Credentials → API key.** Copy it.
3. Find your **Channel ID**: on youtube.com, go to your channel → Settings/About → it's in the URL or channel details (starts with `UC...`).
4. By default this app only pulls from **your own channel** (`YOUTUBE_MODE=channel`) — re-uploading other creators' videos to TikTok without rights is a copyright/ToS risk to your TikTok account. Only switch to `YOUTUBE_MODE=search` if you're intentionally using Creative-Commons-licensed content (it filters for that automatically) or content you have explicit rights to.

## 3. Railway setup

### 3a. Add a persistent Volume (do this or nothing will actually be saved)
Railway → your service → **Settings → Volumes → New Volume**. Mount path: `/data`. Without this, the container's disk resets on every deploy/restart and you're back to the original bug (lost TikTok connection, lost history).

### 3b. Set environment variables
Railway → your service → **Variables**. Add everything from `.env.example` in this bundle, filled in with your real values. Set `DATA_DIR=/data` to match the volume above.

### 3c. Replace your files
In your GitHub repo, replace/add these files exactly as provided:
```
server.js
lib/store.js
lib/tiktok.js
lib/youtube.js
lib/clipper.js
lib/scheduler.js
package.json
railway.toml
Procfile
.env.example   (reference only — don't put real secrets in this file)
```
Commit and push. Railway will auto-deploy. The updated `railway.toml` now also installs `ffmpeg` during build (needed for video clipping) and sets a sturdier restart policy.

> Note: `restartPolicyType = "ALWAYS"` is **not available on Railway's free/trial plan** (it's a paid-plan feature) — this config uses `ON_FAILURE` with the max retry count instead, combined with the app's own auto-resume logic (see below), so the agent comes back on its own either way. If you're on a paid plan and want true always-restart, you can switch it to `ALWAYS` in Railway's dashboard under Settings → Restart Policy.

## 4. First run

1. Open your Railway public URL.
2. Go to **Setup** tab → click **Connect / Reconnect TikTok Account** → log in/authorize on TikTok → you'll be redirected back. The Setup tab now shows a real, persistent "✓ Connected" banner (not a hardcoded message) and tells you whether posts will be public or private right now.
3. Set **Posts Per Day** and save config.
4. Go to **Agent** tab → **Start Automated Posting**.
5. Watch the **Live Logs** card — it now logs every real step (discovering a video, downloading, clipping, uploading, TikTok's actual publish status), not a generic "tick" message.

## 5. How "24/7" actually works now

A Node `setInterval` cannot survive a process restart by itself — that was never going to be reliable regardless of UI polish. This version persists `agent.running = true/false` to disk and calls `resumeOnBoot()` every time the process starts. So: if the agent was running and Railway restarts the container (crash, redeploy, etc.), it automatically goes back to running without you touching anything. You only ever need to click Start once.

## 6. Why you couldn't see clips/insights before, and what's true now

- **Clips tab** now lists every real attempt with a real status: `processing`, `posted`, or `failed` (with the actual error message attached) — not a permanently empty stub.
- **Learn/Performance tab** shows what *this agent* has actually posted. It does **not** show TikTok view/like counts — pulling real analytics requires TikTok's separate Display/Research API with additional scopes and review, which isn't wired up in this build. Flagging this so you don't expect numbers that aren't there yet.
- **Setup → Recent Errors** is new — every failure (YouTube quota, ffmpeg issue, TikTok rejection) lands here with a timestamp instead of disappearing silently.

## 7. Known limitations (honest list, not swept under the rug)

- **Public vs. private posting** depends entirely on TikTok's audit status for your app, as explained above — no code change fixes this.
- **TikTok's own daily cap** is roughly 15 posts per creator per 24h regardless of your `POSTS_PER_DAY` setting — that's enforced TikTok-side.
- **`@distube/ytdl-core`** (the YouTube downloader) occasionally needs a version bump when YouTube changes something internally. If downloads start failing suddenly, check that package's GitHub for a newer release and bump the version in `package.json`.
- **Editing is simple**: this crops/resizes the source to vertical and cuts a ≥60s window. It does not add captions, voiceover, or B-roll — that's a separate feature if you want it later.
- **Keep `numReplicas` at 1** in Railway for this service. The scheduler isn't built for multiple instances running at once — that would double-post.
- Access tokens auto-refresh, but TikTok's refresh token itself expires after about a year of no use — if that ever happens, just reconnect TikTok from Setup.

## 8. Quick troubleshooting

| Symptom | Where to look |
|---|---|
| "Post Now" fails | Setup tab → Recent Errors shows the exact reason (TikTok, YouTube, or ffmpeg error) |
| Nothing posts even though agent says LIVE | Agent tab banner tells you if TikTok isn't connected; Clips tab shows the failed attempt and why |
| Lost connection after a redeploy | Confirm the Volume from step 3a is actually attached and `DATA_DIR` matches its mount path |
| Posts not showing publicly | Setup tab → TikTok Connection banner — almost certainly the audit/SELF_ONLY restriction from section 1 |
