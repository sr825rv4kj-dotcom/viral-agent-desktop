// ============================================================
// lib/store.js
// Tiny persistent JSON store. No native deps (no SQLite build
// headaches on Railway/Nixpacks) — just durable, atomic writes
// to a single JSON file on a Railway Volume.
//
// IMPORTANT: DATA_DIR must point at a Railway Volume mount
// (e.g. /data) or every redeploy wipes your TikTok tokens and
// history again, exactly like the old bug. See SETUP.md.
// ============================================================

const fs = require('fs');
const path = require('path');

const DATA_DIR = process.env.DATA_DIR || '/data';
const DB_FILE = path.join(DATA_DIR, 'viralagent.json');
const TMP_FILE = DB_FILE + '.tmp';

const DEFAULTS = {
  // Agent run state — persisted so the agent can resume itself
  // after a Railway restart without you having to click Start again.
  agent: {
    running: false,
    startedAt: null,
    lastTickAt: null,
  },

  // Counters / history
  stats: {
    postsToday: 0,
    totalPosts: 0,
    lastPost: null,
    dayKey: null, // YYYY-MM-DD, used to reset postsToday at midnight
  },

  // TikTok OAuth tokens — the thing the old code never saved.
  tiktok: {
    connected: false,
    access_token: null,
    refresh_token: null,
    open_id: null,
    scope: null,
    access_token_expires_at: null, // epoch ms
    refresh_token_expires_at: null, // epoch ms
    creator_info: null, // cached privacy_level_options etc.
    creator_info_fetched_at: null,
  },

  // Clip pipeline
  clips: [], // { id, title, sourceUrl, filePath, durationSec, status, postedAt, tiktokPublishId, error }

  logs: [], // string[]
  errors: [], // { at, message }

  config: {
    postsPerDay: parseInt(process.env.POSTS_PER_DAY || '15', 10),
    minViralScore: parseInt(process.env.MIN_VIRAL_SCORE || '70', 10),
  },
};

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function deepMerge(base, override) {
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const k of Object.keys(override || {})) {
    if (
      override[k] && typeof override[k] === 'object' && !Array.isArray(override[k]) &&
      base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])
    ) {
      out[k] = deepMerge(base[k], override[k]);
    } else {
      out[k] = override[k];
    }
  }
  return out;
}

let cache = null;

function load() {
  ensureDir();
  if (!fs.existsSync(DB_FILE)) {
    cache = JSON.parse(JSON.stringify(DEFAULTS));
    save();
    return cache;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    // Merge with defaults so new fields introduced by code updates
    // don't crash on an older saved file.
    cache = deepMerge(DEFAULTS, parsed);
  } catch (err) {
    console.error('[store] Failed to read DB file, recovering with defaults:', err.message);
    // Don't throw away the corrupt file silently — keep a backup for inspection.
    try {
      fs.copyFileSync(DB_FILE, DB_FILE + '.corrupt-' + Date.now());
    } catch (_) {}
    cache = JSON.parse(JSON.stringify(DEFAULTS));
    save();
  }
  return cache;
}

function save() {
  ensureDir();
  // Atomic write: write to tmp file then rename, so a crash mid-write
  // never leaves a half-written/corrupt JSON file behind.
  fs.writeFileSync(TMP_FILE, JSON.stringify(cache, null, 2));
  fs.renameSync(TMP_FILE, DB_FILE);
}

function get() {
  if (!cache) load();
  return cache;
}

function update(mutatorFn) {
  if (!cache) load();
  mutatorFn(cache);
  save();
  return cache;
}

module.exports = { get, update, load, save, DATA_DIR, DB_FILE };
