// ============================================================
// lib/tiktok.js
// Real TikTok OAuth + Content Posting API integration.
// The old code redirected to TikTok's auth screen but never
// exchanged the returned `code` for a token, and never called
// any posting endpoint. This file is the part that was missing.
//
// Docs: https://developers.tiktok.com/doc/content-posting-api-get-started
//
// IMPORTANT REALITY CHECK (not a bug, a TikTok platform rule):
// Until your TikTok Developer app passes TikTok's manual audit,
// every post it publishes is forced to SELF_ONLY (private,
// visible only to you) and only up to 5 TikTok accounts can
// authorize the app per 24h. That's TikTok's restriction, not
// something fixable in code. This file detects that automatically
// via the creator_info endpoint and tells you the truth about it
// in the dashboard instead of hiding it.
// ============================================================

const fs = require('fs');
const store = require('./store');

const API_BASE = 'https://open.tiktokapis.com/v2';

function cfg() {
  return {
    clientKey: process.env.TIKTOK_CLIENT_KEY,
    clientSecret: process.env.TIKTOK_CLIENT_SECRET,
    redirectUri: process.env.TIKTOK_REDIRECT_URI,
  };
}

function getAuthorizeUrl(state) {
  const { clientKey, redirectUri } = cfg();
  const params = new URLSearchParams({
    client_key: clientKey || '',
    scope: 'user.info.basic,video.publish,video.upload',
    response_type: 'code',
    redirect_uri: redirectUri || '',
    state: state || 'viralAgent',
  });
  return `https://www.tiktok.com/v2/auth/authorize/?${params.toString()}`;
}

async function postForm(endpoint, formObj, extraHeaders) {
  const body = new URLSearchParams(formObj).toString();
  const res = await fetch(`${API_BASE}${endpoint}`, {
    method: 'POST',
    headers: Object.assign(
      { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      extraHeaders || {}
    ),
    body,
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

async function postJSON(endpoint, bodyObj, accessToken) {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json; charset=UTF-8',
      Authorization: `Bearer ${accessToken}`,
    },
    body: JSON.stringify(bodyObj),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

// ── Step 1: exchange the OAuth `code` for tokens, and SAVE them ──
async function exchangeCodeForToken(code) {
  const { clientKey, clientSecret, redirectUri } = cfg();
  if (!clientKey || !clientSecret) {
    throw new Error('TIKTOK_CLIENT_KEY / TIKTOK_CLIENT_SECRET not set in Railway env vars');
  }

  const { ok, json } = await postForm('/oauth/token/', {
    client_key: clientKey,
    client_secret: clientSecret,
    code,
    grant_type: 'authorization_code',
    redirect_uri: redirectUri || '',
  });

  if (!ok || json.error) {
    throw new Error(
      `TikTok token exchange failed: ${json.error_description || json.error || 'unknown error'}`
    );
  }

  const now = Date.now();
  store.update((s) => {
    s.tiktok.connected = true;
    s.tiktok.access_token = json.access_token;
    s.tiktok.refresh_token = json.refresh_token;
    s.tiktok.open_id = json.open_id;
    s.tiktok.scope = json.scope;
    s.tiktok.access_token_expires_at = now + (json.expires_in || 86400) * 1000;
    s.tiktok.refresh_token_expires_at = now + (json.refresh_expires_in || 31536000) * 1000;
  });

  return json;
}

// ── Step 2: auto-refresh before the 24h access token expires ──
// TikTok access tokens last ~24h; refresh tokens last ~365 days.
// Without this, the connection silently dies every day — this was
// the "credentials don't stay linked" bug.
async function ensureFreshToken() {
  const s = store.get();
  if (!s.tiktok.connected || !s.tiktok.refresh_token) {
    throw new Error('TikTok is not connected yet — go to Setup and connect your account.');
  }

  const now = Date.now();
  const fiveMinutes = 5 * 60 * 1000;

  if (s.tiktok.refresh_token_expires_at && now > s.tiktok.refresh_token_expires_at) {
    store.update((st) => { st.tiktok.connected = false; });
    throw new Error('TikTok refresh token expired (this happens after ~1 year of inactivity) — please reconnect TikTok in Setup.');
  }

  if (s.tiktok.access_token_expires_at && now < s.tiktok.access_token_expires_at - fiveMinutes) {
    return s.tiktok.access_token; // still valid, no need to refresh
  }

  const { clientKey, clientSecret } = cfg();
  const { ok, json } = await postForm('/oauth/token/', {
    client_key: clientKey,
    client_secret: clientSecret,
    grant_type: 'refresh_token',
    refresh_token: s.tiktok.refresh_token,
  });

  if (!ok || json.error) {
    store.update((st) => { st.tiktok.connected = false; });
    throw new Error(`TikTok token refresh failed: ${json.error_description || json.error}. Please reconnect TikTok in Setup.`);
  }

  store.update((st) => {
    st.tiktok.access_token = json.access_token;
    st.tiktok.refresh_token = json.refresh_token || st.tiktok.refresh_token;
    st.tiktok.access_token_expires_at = now + (json.expires_in || 86400) * 1000;
    if (json.refresh_expires_in) {
      st.tiktok.refresh_token_expires_at = now + json.refresh_expires_in * 1000;
    }
  });

  return json.access_token;
}

// ── Ask TikTok what this account/app is actually allowed to do ──
// Tells us truthfully whether posts will be public or SELF_ONLY,
// instead of assuming.
async function queryCreatorInfo(forceRefresh) {
  const s = store.get();
  const cached = s.tiktok.creator_info;
  const cacheAgeOk = s.tiktok.creator_info_fetched_at && (Date.now() - s.tiktok.creator_info_fetched_at < 5 * 60 * 1000);
  if (cached && cacheAgeOk && !forceRefresh) return cached;

  const accessToken = await ensureFreshToken();
  const { ok, json } = await postJSON('/post/publish/creator_info/query/', {}, accessToken);
  if (!ok || json.error?.code !== 'ok') {
    throw new Error(`creator_info query failed: ${json.error?.message || 'unknown error'}`);
  }
  const info = json.data;
  store.update((st) => {
    st.tiktok.creator_info = info;
    st.tiktok.creator_info_fetched_at = Date.now();
  });
  return info;
}

// ── Post a local video file to TikTok (Direct Post, FILE_UPLOAD) ──
async function postVideoFile(filePath, { title, privacyLevel } = {}) {
  const accessToken = await ensureFreshToken();
  const creatorInfo = await queryCreatorInfo();

  const allowed = creatorInfo.privacy_level_options || [];
  let chosenPrivacy = privacyLevel;
  if (!chosenPrivacy || !allowed.includes(chosenPrivacy)) {
    // Prefer fully public if this app/account is allowed it; otherwise
    // TikTok will only have offered SELF_ONLY (unaudited app) and we
    // must respect that — see queryCreatorInfo / the dashboard warning.
    chosenPrivacy = allowed.includes('PUBLIC_TO_EVERYONE') ? 'PUBLIC_TO_EVERYONE' : (allowed[0] || 'SELF_ONLY');
  }

  const stat = fs.statSync(filePath);
  const videoSize = stat.size;

  const initRes = await postJSON('/post/publish/video/init/', {
    post_info: {
      title: (title || 'New post').slice(0, 150),
      privacy_level: chosenPrivacy,
      disable_duet: false,
      disable_comment: false,
      disable_stitch: false,
      video_cover_timestamp_ms: 1000,
    },
    source_info: {
      source: 'FILE_UPLOAD',
      video_size: videoSize,
      chunk_size: videoSize, // single chunk — fine for short clips
      total_chunk_count: 1,
    },
  }, accessToken);

  if (!initRes.ok || initRes.json.error?.code !== 'ok') {
    throw new Error(`video/init failed: ${initRes.json.error?.message || 'unknown error'}`);
  }

  const { publish_id, upload_url } = initRes.json.data;

  const fileBuffer = fs.readFileSync(filePath);
  const uploadRes = await fetch(upload_url, {
    method: 'PUT',
    headers: {
      'Content-Type': 'video/mp4',
      'Content-Range': `bytes 0-${videoSize - 1}/${videoSize}`,
      'Content-Length': String(videoSize),
    },
    body: fileBuffer,
  });

  if (!uploadRes.ok) {
    throw new Error(`Video upload to TikTok failed with HTTP ${uploadRes.status}`);
  }

  // Poll for completion — publishing is async.
  const finalStatus = await pollPublishStatus(publish_id, accessToken);
  return { publishId: publish_id, privacyUsed: chosenPrivacy, ...finalStatus };
}

async function pollPublishStatus(publishId, accessToken, maxWaitMs = 120000) {
  const start = Date.now();
  while (Date.now() - start < maxWaitMs) {
    const { ok, json } = await postJSON('/post/publish/status/fetch/', { publish_id: publishId }, accessToken);
    if (ok && json.data) {
      const status = json.data.status;
      if (status === 'PUBLISH_COMPLETE') return { status, raw: json.data };
      if (status === 'FAILED') return { status, raw: json.data, error: json.data.fail_reason };
      // PROCESSING_UPLOAD / PROCESSING_DOWNLOAD / SEND_TO_USER_INBOX → keep polling
    }
    await new Promise((r) => setTimeout(r, 3000));
  }
  return { status: 'TIMEOUT' };
}

function isConnected() {
  return !!store.get().tiktok.connected;
}

module.exports = {
  getAuthorizeUrl,
  exchangeCodeForToken,
  ensureFreshToken,
  queryCreatorInfo,
  postVideoFile,
  isConnected,
};
