// ============================================================
// lib/scheduler.js
// The real 24/7 loop: discover → clip → post.
//
// Key fixes vs the old code:
//  - Persists `running` so a Railway restart/redeploy auto-resumes
//    the agent instead of silently going offline (resumeOnBoot()).
//  - One failed tick (bad video, TikTok hiccup, ffmpeg error) is
//    logged and skipped — it does NOT crash or silently stop the
//    whole agent, and does NOT fake a successful post.
//  - Respects a real daily post cap and resets it at UTC midnight.
//  - De-dupes source videos so you don't repost the same clip.
// ============================================================

const store = require('./store');
const youtube = require('./youtube');
const tiktok = require('./tiktok');
const clipper = require('./clipper');
const fs = require('fs');

let timer = null;

function log(msg) {
  const entry = `[${new Date().toISOString()}] ${msg}`;
  console.log(entry);
  store.update((s) => {
    s.logs.unshift(entry);
    if (s.logs.length > 200) s.logs.length = 200;
  });
}

function logError(err) {
  const message = err && err.message ? err.message : String(err);
  console.error('[agent error]', message);
  store.update((s) => {
    s.errors.unshift({ at: new Date().toISOString(), message });
    if (s.errors.length > 100) s.errors.length = 100;
  });
  log(`❌ ${message}`);
}

function todayKey() {
  return new Date().toISOString().slice(0, 10); // UTC YYYY-MM-DD
}

function resetDailyCounterIfNewDay() {
  store.update((s) => {
    const key = todayKey();
    if (s.stats.dayKey !== key) {
      s.stats.dayKey = key;
      s.stats.postsToday = 0;
    }
  });
}

async function tick() {
  const s = store.get();
  if (!s.agent.running) return;

  resetDailyCounterIfNewDay();
  store.update((st) => { st.agent.lastTickAt = new Date().toISOString(); });

  const cap = s.config.postsPerDay;
  if (store.get().stats.postsToday >= cap) {
    log(`Daily cap reached (${cap}/day) — waiting until tomorrow.`);
    return;
  }

  if (!tiktok.isConnected()) {
    log('⏸ Agent is running but TikTok is not connected yet — go to Setup and connect your account. Skipping this tick.');
    return;
  }

  try {
    log('🔍 Looking for a source video...');
    const excludeIds = store.get().clips.map((c) => c.sourceVideoId).filter(Boolean);
    const candidates = await youtube.discoverCandidateVideos({ limit: 5, excludeIds });

    if (!candidates.length) {
      log('No new eligible source videos found this tick (none long enough, or all already used).');
      return;
    }

    const video = candidates[0];
    log(`📹 Selected source: "${video.title}" (${video.durationSec}s)`);

    const clipId = `${video.videoId}-${Date.now()}`;
    store.update((s2) => {
      s2.clips.unshift({
        id: clipId,
        title: video.title,
        sourceVideoId: video.videoId,
        sourceUrl: video.url,
        status: 'processing',
        durationSec: null,
        postedAt: null,
        tiktokPublishId: null,
        error: null,
        createdAt: new Date().toISOString(),
      });
      if (s2.clips.length > 300) s2.clips.length = 300;
    });

    log('✂️ Downloading & cutting clip...');
    const { filePath, durationSec } = await clipper.createClipFromYouTube(video);
    log(`✅ Clip ready: ${durationSec.toFixed(1)}s`);

    try {
      log('📤 Uploading to TikTok...');
      const result = await tiktok.postVideoFile(filePath, { title: video.title });

      if (result.status !== 'PUBLISH_COMPLETE') {
        throw new Error(`TikTok publish did not complete (status: ${result.status}${result.error ? ', reason: ' + result.error : ''})`);
      }

      store.update((s2) => {
        const clip = s2.clips.find((c) => c.id === clipId);
        if (clip) {
          clip.status = 'posted';
          clip.durationSec = durationSec;
          clip.postedAt = new Date().toISOString();
          clip.tiktokPublishId = result.publishId;
          clip.privacyUsed = result.privacyUsed;
        }
        s2.stats.postsToday += 1;
        s2.stats.totalPosts += 1;
        s2.stats.lastPost = new Date().toISOString();
      });

      const visibilityNote = result.privacyUsed === 'PUBLIC_TO_EVERYONE'
        ? 'public'
        : `${result.privacyUsed} (TikTok is restricting visibility — see Setup tab)`;
      log(`🎉 Posted to TikTok — visibility: ${visibilityNote}`);
    } finally {
      fs.unlink(filePath, () => {}); // clean up the local clip file either way
    }
  } catch (err) {
    // Mark the in-flight clip (if any) as failed instead of leaving it
    // stuck on "processing" forever, and instead of faking success.
    store.update((s2) => {
      const clip = s2.clips.find((c) => c.status === 'processing');
      if (clip) {
        clip.status = 'failed';
        clip.error = err.message;
      }
    });
    logError(err);
  }
}

function scheduleNext() {
  if (timer) clearInterval(timer);
  const postsPerDay = Math.max(1, store.get().config.postsPerDay);
  const intervalMs = Math.floor((24 * 60 * 60 * 1000) / postsPerDay);
  timer = setInterval(() => { tick().catch(logError); }, intervalMs);
  return intervalMs;
}

function start() {
  const wasRunning = store.get().agent.running;
  store.update((s) => {
    s.agent.running = true;
    if (!wasRunning) s.agent.startedAt = new Date().toISOString();
  });
  const intervalMs = scheduleNext();
  log(`Agent started — posting roughly every ${Math.round(intervalMs / 60000)} minutes (cap ${store.get().config.postsPerDay}/day).`);
  tick().catch(logError); // run one immediately so you see activity right away
  return intervalMs;
}

function stop() {
  store.update((s) => { s.agent.running = false; });
  if (timer) { clearInterval(timer); timer = null; }
  log('Agent stopped.');
}

// Call this once at server boot. If the agent was running before the
// last restart/redeploy, this brings it back automatically — that's
// the actual mechanism for "24/7", since a setInterval timer cannot
// survive a process restart on its own.
function resumeOnBoot() {
  if (store.get().agent.running) {
    log('Resuming agent after restart (it was running before this restart).');
    scheduleNext();
    tick().catch(logError);
  }
}

function updateConfig({ postsPerDay, minViralScore }) {
  store.update((s) => {
    if (postsPerDay) s.config.postsPerDay = Math.max(1, Math.min(50, postsPerDay));
    if (minViralScore !== undefined) s.config.minViralScore = Math.max(0, Math.min(100, minViralScore));
  });
  if (store.get().agent.running) scheduleNext(); // re-space ticks to the new rate
}

module.exports = { start, stop, resumeOnBoot, tick, updateConfig, log, logError };
